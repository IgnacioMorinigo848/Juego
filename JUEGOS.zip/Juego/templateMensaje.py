def mensajePrincipla():
    print()
    print("Bienvenido a TA TE TI")
    print("1. Jugar Partida")
    print("2. Ver Historial De Juego")
    print("3. Salir")
    print()

def mensajeJugar():
    print()
    print("Bienvenido al Panel de Juego")
    print("1. Jugar Partida Rapida")
    print("2. Jugar Multijugador")
    print("3. Voler al Menu Principal")
    print()

def mensajeJuegoTerminado():
    print("1. Volver a Jugar")
    print("2. Volver al Menu Principal.")
    
def mensajeJugarPartidaRapida():
    print("Modo Partida Rapida.")
    
def mesajeJugarMitijugador():
    print("Modo Multijugador.")

def mensajeError():
    return print("Error, ingrese la opcion correcta.")