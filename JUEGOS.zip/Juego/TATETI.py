"""
-----------------------------------------------------------------------------------------------
Título:
Fecha:
Autor:
Descripción:
-----------------------------------------------------------------------------------------------
"""

#----------------------------------------------------------------------------------------------
# MÓDULOS IMPORTADOS
#----------------------------------------------------------------------------------------------
import templateMensaje
import random
#----------------------------------------------------------------------------------------------
# FUNCIONES
#----------------------------------------------------------------------------------------------
    
    
def selectorGlobal(mensaje):
    return int(input(f"Ingrese la {mensaje}:"))

def controlDeOpcionGlobal(inicio, final):
    while True:
        try:
            opcion = selectorGlobal("opcion")
            if opcion in range(inicio, final+1):
                break
            templateMensaje.mensajeError()
        except ValueError:
            templateMensaje.mensajeError()

    return opcion

def juegoTerminado():
    templateMensaje.mensajeJuegoTerminado()
    opcion = controlDeOpcionGlobal(1, 2)
    if opcion == 1:
        jugar()
    else:
        menuPrincipal()

def hayGanador(tablero, jugador):
    ganador = False
    # Validar Horizontal
    if tablero[0][0] == tablero[0][1] == tablero[0][2] == jugador or \
       tablero[1][0] == tablero[1][1] == tablero[1][2] == jugador or \
       tablero[2][0] == tablero[2][1] == tablero[2][2] == jugador:
        ganador = True
    # Validar Vertical
    elif tablero[0][0] == tablero[1][0] == tablero[2][0] == jugador or \
         tablero[0][1] == tablero[1][1] == tablero[2][1] == jugador or \
         tablero[0][2] == tablero[1][2] == tablero[2][2] == jugador:
        ganador = True
    # Validar Diagonal
    elif tablero[0][0] == tablero[1][1] == tablero[2][2] == jugador or \
         tablero[0][2] == tablero[1][1] == tablero[2][0] == jugador:
        ganador = True
    return ganador

def cargarTablero(ficha, posicion, tablero):
    for f in range(len(tablero)):
        for c in range(len(tablero[0])):
            if tablero[f][c] == str(posicion):
                tablero[f][c] = ficha
                return tablero
    print("La posición ya ha sido ocupada.")
    posicionNueva = selectorGlobal("opcion")
    return cargarTablero(ficha, posicionNueva, tablero)


def crearTablero():
    return [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"]]

def mostrarTablero(tablero):
    SEPARADOR = "----------------------------"
    ANCHO_CELDA = 8
    print(SEPARADOR)
    for fila in tablero:
        for celda in fila:
            celda_centralizada = str(celda).center(ANCHO_CELDA)
            print(f"|{celda_centralizada}", end="")
        print("|")
        print(SEPARADOR)

def mostrarFichas():
    fichas = ["☺", "☻", "♂", "♠", "♣", "○", "◙", "¶", "▲", "♥", "♦", "•", "◘"]
    numeros = "      ".join(["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"])
    print("Seleccione su ficha de juego.")
    print()
    print("|-----------------------------------------------------------------------------------------|")
    for i in range(len(fichas)):
        print(f"{fichas[i]} {i + 1}",end=" - ")
    print()
    print("|-----------------------------------------------------------------------------------------|")
    print()
    while True:
        try:
            opcion = selectorGlobal("opcion")
            ficha = fichas[opcion - 1]
            break
        except ValueError:
            templateMensaje.mensajeError()
        except IndexError:
            templateMensaje.mensajeError()
    return ficha

def backUpFicha():
    fichasEnJuego = []
    for i in range(2):
        print()
        print(f"Turno del Jugador {i+1}.")
        ficha = mostrarFichas()
        fichasEnJuego.append(ficha)
    return fichasEnJuego


def iA(tablero, ficha_IA, ficha_oponente):
    movimientos_posibles = []

    for fila in tablero:
        for casilla in fila:
            if casilla != ficha_IA and casilla != ficha_oponente:
                movimientos_posibles.append(casilla)

    for movimiento in movimientos_posibles:
        nuevo_tablero = [fila[:] for fila in tablero]  
        nuevo_tablero = cargarTablero(ficha_IA, movimiento, nuevo_tablero) 
        if hayGanador(nuevo_tablero, ficha_IA):
            return movimiento

    for movimiento in movimientos_posibles:
        nuevo_tablero = [fila[:] for fila in tablero]  
        nuevo_tablero = cargarTablero(ficha_oponente, movimiento, nuevo_tablero) 
        if hayGanador(nuevo_tablero, ficha_oponente):
            return movimiento

    return random.choice(movimientos_posibles)


def jugarMultijugador(jugadas=0, empate = False):
    templateMensaje.mesajeJugarMitijugador()
    fichasEnJuego = backUpFicha()
    tablero = crearTablero()
    mostrarTablero(tablero)
    while True:
        for i in range(1, 3):
            print(f"Turno del Jugador {i}")
            posicion = selectorGlobal("posicion")
            tablero = cargarTablero(fichasEnJuego[i - 1], posicion, tablero)
            ganadorEncontrado = hayGanador(tablero, fichasEnJuego[i - 1])
            mostrarTablero(tablero)
            jugadas += 1
            if jugadas == 9 and not ganadorEncontrado:
                empate = True
                break
            if ganadorEncontrado:
                print(f"El jugador {i} ha ganado.")
                break
        if ganadorEncontrado:
            break
        if empate:
            print("Empate. No hay ganador.")
            break
    print()
    juegoTerminado()


def jugarPartidaRapida(jugadas=0, empate=False):
    templateMensaje.mensajeJugarPartidaRapida()
    fichasEnJuego = backUpFicha()
    tablero = crearTablero()
    mostrarTablero(tablero)
    while True:
        for i in range(1, 3):
            if i == 1:
                print(f"Es turno de la máquina.")
                posicion = iA(tablero, fichasEnJuego[i - 1],fichasEnJuego[i])
            else:
                print(f"Turno del Jugador {i}")
                posicion = selectorGlobal("posicion")
            tablero = cargarTablero(fichasEnJuego[i - 1], posicion, tablero)
            ganadorEncontrado = hayGanador(tablero, fichasEnJuego[i - 1])
            mostrarTablero(tablero)
            jugadas += 1
            if jugadas == 9:
                empate = True
                break
            if ganadorEncontrado:
                print(f"El jugador {i} ha ganado.")
                break
        if empate:
            print("Empate. No hay ganador.")
            break
        if ganadorEncontrado: 
            break
    print()
    juegoTerminado()

    

def jugar():
    templateMensaje.mensajeJugar()
    opcion = controlDeOpcionGlobal(1, 3)
    if opcion == 1:
        jugarPartidaRapida()
    elif opcion == 2:
        jugarMultijugador()
    else:
        menuPrincipal()

def menuPrincipal():
    templateMensaje.mensajePrincipla()
    opcion = controlDeOpcionGlobal(1, 2)
    if opcion == 1:
        jugar()
    else:
        print("Gracias por Jugar.")
        exit()

    
#----------------------------------------------------------------------------------------------
# CUERPO PRINCIPAL
#----------------------------------------------------------------------------------------------
# Declaración de variables
#----------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------
# Bloque de menú
#----------------------------------------------------------------------------------------------
menuPrincipal()
